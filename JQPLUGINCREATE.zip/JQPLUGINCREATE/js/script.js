(function($){
	
	$.fn.modalfy = function(options){
		var $modalCon = $(".modalCon");
		
		return this.click(function(e){
			if (typeof options !== 'undefined' && options !== null) {
				if(options.action == "fade"){
					$modalCon.fadeToggle("fast");
				}
				else if(options.action == "slide"){
					$modalCon.slideToggle("fast");
				}
				else if(options.action == "maximize"){
					$modalCon.toggle("fast");
				}
			}
			else {
				$modalCon.show();
			}
		});
	};
	
}(jQuery));



$(document).ready(function(){
	$(".modalBasic").modalfy();
	$(".modalFade").modalfy({
		action: "fade"
	});
	$(".modalSlide").modalfy({
		action: "slide"
	});
	$(".modalMaximize").modalfy({
		action: "maximize"
	});
});
