$(window).load(function() {
	$('.productsArea ul li').autoHeight();
});