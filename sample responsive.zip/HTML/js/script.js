$(document).ready(function(){
	/* -----------------------
	SLIDER
	------------------------- */
	set_auto_slide();
	get_bread();
	
	$('.arrows .right').click(function(e){
		e.preventDefault();
		move('next');
	});
	$('.arrows .left').click(function(e){
		e.preventDefault();
		move('prev');
	});
	
	function set_auto_slide(){
		autoSlide = setTimeout(function(){
			move('next');
		}, 5000);
	}
	
	function set_up_bg(){
		$('.bnr-area ul.contents li').each(function(){
			var $bg = $(this).children('.bg').children('img').attr('src');
			$(this).css('background-image', 'url(' + $bg + ')');
		});
	}
	set_up_bg();
	
	function move(act){
		clearTimeout(autoSlide);
		
		var $current = $('.bnr-area ul.contents li.active');
		if(act == "next"){
			var $next = $('.bnr-area ul.contents li.active').next();
			if($next.length == 0){
				$next = $('.bnr-area ul.contents li').first();
			}
		}
		else {
			var $next = $('.bnr-area ul.contents li.active').prev();
			console.log($next.length);
			if($next.length == 0){
				$next = $('.bnr-area ul.contents li').last();
			}
		}
		
		
		$current.find('.content').animate({
			top: '120px'
		},600).animate({
			top: '0px'
		},1);

		$current.fadeOut('slow');
		$next.fadeIn('slow');

		$('.bnr-area ul.contents li').removeClass('active');
		$next.addClass('active');
		
		set_auto_slide();
	}
	
	
	
	/* -----------------------
	SCREEN RESIZE
	------------------------- */
	$(window).resize(function() {
		get_bread();
	});
	
	function get_bread(){
		var ww = $(window).width();

		if(ww <= 1334){
			if($('header div.menu').find('p').length <= 0){
				$('header div.menu').prepend('<p><a href="#"><img src="images/header-menu_con.png"></ap></p>');

				$('header div.menu').removeClass('pc');
				$('header div.menu').addClass('sp');
			}
		}
		else {
			if($('header div.menu').find('p').length >= 1){
				$('header div.menu p').remove();

				$('header div.menu').removeClass('sp');
				$('header div.menu').addClass('pc');
			}
		}
	}
	
	
});