
@foreach ($cards_list as $card)
	"{{ $card->card_id }}",
@endforeach