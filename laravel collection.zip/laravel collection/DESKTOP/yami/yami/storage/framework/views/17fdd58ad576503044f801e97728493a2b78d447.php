
<?php foreach($cards_list as $card): ?>
	"<?php echo e($card->id); ?>","<?php echo e($card->class); ?>","<?php echo e($card->name); ?>","<?php echo e($card->level); ?>","<?php echo e($card->attribute); ?>","<?php echo e($card->type); ?>","<?php echo e($card->attack); ?>","<?php echo e($card->defence); ?>","<?php echo e($card->description); ?>"][
<?php endforeach; ?>