
<?php foreach($chatmsg as $msg): ?>
<li id='<?php echo e($msg->id); ?>'>
	<?php if( $msg->user_name == session('user_name') ): ?>

		<div class="tbl">
			<div class="cell pr05 avatar">
				<div class="pic">
					<?php if( $msg->avatar ): ?>
						<img src="<?php echo e($msg->avatar); ?>">
					<?php else: ?>
						<img src='/common/images/pic_default.png'>
					<?php endif; ?>
				</div>
				<div class="name">
					<?php echo e($msg->user_name); ?>

				</div>
			</div>
			<div class="cell">
				<div class="chatmine">
					<div class="msg"><?php echo e($msg->msg); ?></div>
					<div class="time"><?php echo e($msg->post_time); ?></div>
				</div>
			</div>
		</div>

		<script>
			newMsg = "";
			document.title = "Room | YAMI YUGI";
		</script>
	<?php else: ?>
	
		<div class="tbl">
			<div class="cell pr05 avatar">
				<div class="pic">
					<?php if( $msg->avatar ): ?>
						<img src="<?php echo e($msg->avatar); ?>">
					<?php else: ?>
						<img src='/common/images/pic_default.png'>
					<?php endif; ?>
				</div>
				<div class="name">
					<?php echo e($msg->user_name); ?>

				</div>
			</div>
			<div class="cell">
				<div class="chatothers">
					<div class="msg"><?php echo e($msg->msg); ?></div>
					<div class="time"><?php echo e($msg->post_time); ?></div>
				</div>
			</div>
		</div>

		<script>
			newMsg = "Continue";
			refreshTitle();
		</script>
	<?php endif; ?>



	
	
</li>
<?php endforeach; ?>
