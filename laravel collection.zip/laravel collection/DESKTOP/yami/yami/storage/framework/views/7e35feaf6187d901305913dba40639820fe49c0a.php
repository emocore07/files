
<?php foreach($cards_list as $card): ?>
	"<?php echo e($card->card_id); ?>",
<?php endforeach; ?>