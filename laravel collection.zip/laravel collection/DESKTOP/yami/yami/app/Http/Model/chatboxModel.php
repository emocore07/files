<?php

namespace App\Http\Model;

use Illuminate\Database\Eloquent\Model;

class chatboxModel extends Model
{
	protected $table = 'chatbox';
}
