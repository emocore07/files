<?php

namespace App\Http\Model;

use Illuminate\Database\Eloquent\Model;

class usersModel extends Model
{
	protected $table = 'users';
}
