<?php

namespace App\Http\Model;

use Illuminate\Database\Eloquent\Model;

class cardsModel extends Model
{
	protected $table = 'cards_list';
}
