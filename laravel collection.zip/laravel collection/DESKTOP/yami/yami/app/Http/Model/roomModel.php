<?php

namespace App\Http\Model;

use Illuminate\Database\Eloquent\Model;

class roomModel extends Model
{
	protected $table = 'rooms';
}
